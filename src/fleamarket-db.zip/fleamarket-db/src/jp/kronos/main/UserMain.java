package jp.kronos.main;

import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import jp.kronos.dao.ItemDao;
import jp.kronos.dao.UserDao;
import jp.kronos.dto.Item;
import jp.kronos.dto.User;

public class UserMain {
	// ログインユーザ情報
	private static User user = null;

	// 標準入力を取得するクラス（Scanner）
	private static Scanner scan = new Scanner(System.in);

	// データベース接続情報
	private final static String URL = "jdbc:mysql://localhost:3306/fleamarket?allowPublicKeyRetrieval=true&useSSL=false";
	private final static String USER = "root";
	private final static String PASSWORD = ""; // TODO パスワードの設定

	/**
	 * ログイン
	 * @throws SQLException
	 */
	private static void login() throws SQLException {
		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
			UserDao userDao = new UserDao(con);

			while (true) {
				System.out.println("【ログイン】");
				System.out.print("メールアドレス：");
				String email = scan.next();
				System.out.print("パスワード：");
				String passwd = scan.next();

				// ユーザ情報の取得
				user = userDao.findByEmailAndPassword(email, passwd);
				if (user == null) {
					System.out.println("\r\nメールアドレスまたはパスワードが正しくありません。\r\n");
					continue;
				}
				System.out.println("\r\nようこそ！" + user.getNickname() + "さん\r\n");
				break;
			}
		}
	}

	/**
	 * コンソール表示時の整形用
	 * @param target 表示対象の文字列
	 * @param length 文字列の長さ
	 * @param alignLight 右寄せ
	 * @return
	 */
	private static String format(String target, int length, boolean alignLight) {
		int byteDiff = (target.getBytes(Charset.forName("UTF-8")).length - target.length()) / 2;
		return String.format("%" + (alignLight ? "" : "-") + (length - byteDiff) + "s", target);
	}

	/**
	 * 商品一覧表示
	 * @param keyword 検索キーワード
	 * @throws SQLException
	 */
	static void showItems(String keyword) throws SQLException {
		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
			List<Item> items = new ArrayList<>();

			ItemDao itemDao = new ItemDao(con);
			
			// 商品情報を取得する
			if (keyword == null || keyword.isEmpty()) {
				// 全件検索
				items = itemDao.findAll();
			} else {
				// 曖昧検索（部分一致検索）
				/*
				 * TODO ItemDaoのfindByKeywordメソッドで曖昧検索（部分一致検索）をする
				 */
				
			}

			System.out.println("【商品一覧】");
			System.out.println(format("ID", 4, true) + " | " +
					format("商品名", 50, false) + " | " +
					format("価格", 8, true) + " | " +
					format("状態", 4, false) + " | " +
					format("更新日", 22, true) + " |");
			System.out.println(
					"-----------------------------------------------------------------------------------------------------");
			for (Item item : items) {
				System.out.println(format(item.getId().toString(), 4, true) + " | " +
						format(item.getName(), 50, false) + " | " +
						format(item.getPrice().toString(), 8, true) + " | " +
						format(item.getState(), 4, false) + " | " +
						format(item.getUpdatedDt().toString(), 22, true) + " |");
			}
		}
	}

	/**
	 * 出品処理
	 */
	static void create() {
		System.out.println();
		System.out.println("【出品】");
		System.out.println("------ 出品する商品情報を入力してください ------");

		System.out.print("商品名：");
		String name = scan.next();
		System.out.print("価格：");
		int price = scan.nextInt();
		System.out.print("状態：");
		String state = scan.next();

		/*
		 *  TODO Itemクラスのインスタンスを生成し、登録内容をセットする
		 *  商品名  : 入力した商品名
		 *  価格    : 入力した価格
		 *  状態    : 入力した状態
		 *  出品者ID: 任意のユーザID（固定）
		 */

		
		/*
		 * TODO
		 * ItemDAOのcreateメソッドを実行する
		 * 成功終了時：
		 *   「商品を登録しました。」
		 * 例外発生時：
		 *   「商品の登録に失敗しました。」
		 */
		

		System.out.println();
	}

	/**
	 * 商品更新処理
	 */
	static void update() {
		System.out.println();
		System.out.println("【商品更新】");
		System.out.println("------ 更新するIDを入力してください ------");

		System.out.print("ID：");
		int id = scan.nextInt();

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
			ItemDao itemDao = new ItemDao(con);
			
			/*
			 * TODO
			 * ItemDAOのfindByIdメソッドを実行して指定したIDが存在するかチェックする
			 * 存在しない場合はメッセージを表示して更新処理を終了する
			 * 「指定したIDの商品は見つかりません」
			 */

			
			System.out.println();
			System.out.println("------ 更新内容を入力してください --------");
			System.out.print("商品名：");
			String name = scan.next();
			System.out.print("価格：");
			int price = scan.nextInt();
			System.out.print("状態：");
			String state = scan.next();
	
			/*
			 * TODO
			 * Itemクラスのインスタンスを生成し、更新内容をセットする
			 * ItemDAOのupdateメソッドを実行する
			 * 成功終了時：
			 *   「商品を更新しました。」
			 * 例外発生時：
			 *   「商品の更新に失敗しました。」
			 */
			
			
		} catch (SQLException e) {
			System.out.println("\r\n商品の更新に失敗しました。");
			System.out.println(e.getMessage());
		}
			
		System.out.println();
	}

	/**
	 * 商品削除処理
	 */
	static void delete() {
		System.out.println();
		System.out.println("【商品削除】");
		System.out.println("------ 削除するIDを入力してください ------");

		System.out.print("ID：");
		int id = scan.nextInt();

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
			ItemDao itemDao = new ItemDao(con);
			
			/*
			 * TODO
			 * ItemDAOのfindByIdメソッドを実行して指定したIDが存在するかチェックする
			 * 存在しない場合はメッセージを表示して削除処理を終了する
			 * 「指定したIDの商品は見つかりません」
			 */

		
			/*
			 * TODO
			 * ItemDAOのupdateメソッドを実行する
			 * 成功終了時：
			 *   「商品を削除しました。」
			 * 例外発生時：
			 *   「商品の削除に失敗しました。」
			 */
			
		} catch (SQLException e) {
			System.out.println("\r\n商品の削除に失敗しました。");
			System.out.println(e.getMessage());
		}
		
		System.out.println();
	}

	public static void main(String[] args) {

		String keyword = "";

		System.out.println("**********************");
		System.out.println("**  みんなのフリマ  **");
		System.out.println("**********************");

		// ログイン処理
		try {
			login();
		} catch (SQLException e) {
			System.out.println("\r\nシステムエラーが発生しました。");
			System.out.println(e.getMessage());
			return;
		}

		loop:
		while (true) {
			// 商品一覧表示
			try {
				showItems(keyword);
				keyword = "";
			} catch (SQLException e) {
				System.out.println("システムエラーが発生しました。");
				System.out.println(e.getMessage());
				return;
			}

			System.out.println("\r\n***** メニュー *****");
			System.out.println("1:検索　2:出品　3:更新　4:削除　9:ログアウト");
			int selected = 0;
			selected = scan.nextInt();
			scan.nextLine();  // 残存する改行コードを処理するため

			switch (selected) {
			case 1:
				// 検索処理
				System.out.println();
				System.out.println("-----------------------------------------------");
				System.out.println("検索キーワードで商品名の部分一致検索をします。");
				System.out.println("※未入力の場合は全件検索します。");
				System.out.println("-----------------------------------------------");
				System.out.print("検索キーワード：");
				keyword = scan.nextLine();
				System.out.println();
				// ※keyword値は次のループでshowItems()メソッドに渡される
				
				break;
			case 2:
				// 出品処理
				create();
				break;
			case 3:
				// 商品更新処理
				update();
				break;
			case 4:
				// 商品削除処理
				delete();
				break;
			case 9:
				System.out.println("\r\nログアウトしました。");
				break loop;
			default:
				System.out.println("\r\n入力された処理番号が不正です。\r\n");
				continue;
			}
		}
	}
}
