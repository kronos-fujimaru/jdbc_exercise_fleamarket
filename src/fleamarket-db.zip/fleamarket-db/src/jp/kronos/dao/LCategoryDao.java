package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.kronos.dto.LCategory;

public class LCategoryDao {
	protected Connection con;

	public LCategoryDao(Connection con) {
		this.con = con;
	}
	
	/**
	 * 大カテゴリ登録
	 * @param lCategory 大カテゴリ情報
	 * @return 登録件数
	 * @throws SQLException
	 */
	public int create(LCategory lCategory) throws SQLException {
        String sql = "INSERT INTO l_category (name) "
        		   + "VALUES (?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, lCategory.getName());

            return ps.executeUpdate();

        }
    }
}
