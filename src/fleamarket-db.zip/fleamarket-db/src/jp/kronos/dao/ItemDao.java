package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.kronos.dto.Item;

public class ItemDao {
	protected Connection con;

	public ItemDao(Connection con) {
		this.con = con;
	}

	/**
	 * 全件検索
	 * @return 商品データ（複数）
	 * @throws SQLException
	 */
	public List<Item> findAll() throws SQLException {
		String sql = "SELECT * FROM item";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ResultSet rs = ps.executeQuery();
			List<Item> items = new ArrayList<>();
			
			while (rs.next()) {
				Item item = new Item();
				item.setId(rs.getInt("id"));
				item.setName(rs.getString("name"));
				item.setPrice(rs.getInt("price"));
				item.setState(rs.getString("state"));
				item.setUpdatedDt(rs.getTimestamp("updated_dt"));
				items.add(item);
			}
			return items;
		}
	}
	
	/**
	 * 商品名による部分一致検索
	 * @param keyword 検索キーワード（商品名）
	 * @return 商品情報（複数）
	 * @throws SQLException
	 */
	public List<Item> findByKeyword(String keyword) throws SQLException {
		/*
    	 * TODO
    	 * 引数のkeywordをもとに商品名による部分一致検索で商品データを取得する
    	 * 必要な情報を格納したItemインスタンスが入ったListを返す
    	 */
		return null;
	}
	
	/**
     * 一件検索
     * @param id 商品ID
     * @return 商品情報（一件）
     *          データが存在しない場合はNullを返す
     */
    public Item findById(int id) throws SQLException {
    	/*
    	 * TODO
    	 * 引数のIDをもとに商品情報を取得する
    	 * データが存在する場合
    	 * 　必要な情報を格納したItemインスタンスを返す
    	 * データが存在しない場合
    	 * 　Nullを返す
    	 */
        return null;
    }
	
	/**
     * 商品登録
     * @param item 商品情報
     */
    public void create(Item item) throws SQLException {
    	/*
    	 * TODO
    	 * 引数のItemインスタンスをもとに商品データを登録する
    	 * 登録時には以下のカラムに値をセットする
    	 * 　商品名（NAME）、価格（PRICE）、状態（STATE）、出品者ユーザID（SELLER_ID）
    	 */
        
    }
    
    /**
     * 商品更新
     * @param item 商品情報
     */
    public void update(Item item) throws SQLException {
    	/*
    	 * TODO
    	 * 引数のItemインスタンスをもとに商品データを更新する
    	 * 更新時には以下のカラムに値をセットする
    	 * 　商品名（NAME）、価格（PRICE）、状態（STATE）
    	 */
        
    }

    /**
     * 商品削除
     * @param id 削除対象ID
     */
    public void delete(int id) throws SQLException {
    	/*
    	 * TODO
    	 * 引数のIDに紐づく商品データを削除する
    	 */
    }
    

}
