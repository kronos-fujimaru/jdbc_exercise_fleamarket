package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.kronos.dto.MCategory;

public class MCategoryDao {
	protected Connection con;

	public MCategoryDao(Connection con) {
		this.con = con;
	}
	
	/**
	 * 中カテゴリ登録
	 * @param lCategory 中カテゴリ情報
	 * @return 登録件数
	 * @throws SQLException
	 */
	public int create(MCategory mCategory) throws SQLException {
        String sql = "INSERT INTO m_category (name, l_cat_id) "
        		   + "VALUES (?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, mCategory.getName());
            ps.setInt(2, mCategory.getLCatId());

            return ps.executeUpdate();

        }
    }
}
