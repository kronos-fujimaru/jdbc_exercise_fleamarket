package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.kronos.dto.User;

public class UserDao {
	protected Connection con;

	public UserDao(Connection con) {
		this.con = con;
	}
	
	/**
	 * 一件検索
	 * @param email メールアドレス
	 * @param passwd パスワード
	 * @return ユーザ情報
	 * @throws SQLException
	 */
	public User findByEmailAndPassword(String email, String passwd) throws SQLException {
		User user = null;
		String sql = "SELECT * FROM user WHERE email = ? and password = ?";
		
		try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, passwd);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setEmail(rs.getString("email"));
                user.setNickname(rs.getString("nickname"));
                user.setRegion(rs.getString("region"));
                return user;
            }
            
            return null;

        }
	}
}
