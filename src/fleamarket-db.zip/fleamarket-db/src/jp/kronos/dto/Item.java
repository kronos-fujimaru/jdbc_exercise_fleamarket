package jp.kronos.dto;

import java.sql.Timestamp;

public class Item {
	private Integer id;
	private String name;
	private Integer price;
	private String state;
	private Integer mCatId;
	private Integer publicFlg;
	private Integer sellerId;
	private Integer buyerId;
	private Timestamp purchaseDt;
	private Timestamp updatedDt;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getMCatId() {
		return mCatId;
	}
	public void setMCatId(Integer mCatId) {
		this.mCatId = mCatId;
	}
	public Integer getPublicFlg() {
		return publicFlg;
	}
	public void setPublicFlg(Integer publicFlg) {
		this.publicFlg = publicFlg;
	}
	public Integer getSellerId() {
		return sellerId;
	}
	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}
	public Integer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}
	public Timestamp getPurchaseDt() {
		return purchaseDt;
	}
	public void setPurchaseDt(Timestamp purchaseDt) {
		this.purchaseDt = purchaseDt;
	}
	public Timestamp getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}
}
